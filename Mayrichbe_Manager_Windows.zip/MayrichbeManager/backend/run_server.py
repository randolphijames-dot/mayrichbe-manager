"""
PyInstaller 打包入口
运行内嵌的 FastAPI 服务器（供 Electron 主进程调用）
"""
import os
import sys
import uvicorn

# PyInstaller 打包后资源路径修正
if getattr(sys, 'frozen', False):
    # 打包后：运行目录 = 可执行文件所在目录
    base_dir = os.path.dirname(sys.executable)
    os.chdir(base_dir)

# 读取端口（Electron 主进程通过环境变量传入）
port = int(os.environ.get("PORT", 8000))
host = os.environ.get("HOST", "127.0.0.1")

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        log_level="warning",
    )
